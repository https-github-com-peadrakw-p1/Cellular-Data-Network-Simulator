---
layout: layouts/post.njk
title: About Me
tags:
  - nav
navtitle: About
templateClass: tmpl-post
---

I am a person that writes stuff.
