export default function Layout({ children }) {
  return children;
}
