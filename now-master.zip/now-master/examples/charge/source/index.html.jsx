import About from './pages/about.html.mdx';

export default () => {
  return (
    <>
      <h1>Welcome to my new Charge site!</h1>
      <About />
    </>
  );
};
