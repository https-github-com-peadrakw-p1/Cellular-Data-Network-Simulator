const state = {
    num: 0,
    clicks: 0,
};

export default state;
