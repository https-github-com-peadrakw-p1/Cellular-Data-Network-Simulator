---
title: My First Post
date: 2012-08-20
layout: post.html
---

An interesting post about how it's going to be different this time around. I'm going to write a lot more nowadays and use this blog to improve my writing.
