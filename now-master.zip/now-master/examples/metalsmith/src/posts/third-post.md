---
title: My Third Post
date: 2012-09-28
layout: post.html
---

A slightly late, less interesting piece of prose.
