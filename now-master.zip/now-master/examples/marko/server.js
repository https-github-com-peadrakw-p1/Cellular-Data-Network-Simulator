require('./project').server({
  httpPort: process.env.PORT || 8080, // Optional, but added here for demo purposes
});
