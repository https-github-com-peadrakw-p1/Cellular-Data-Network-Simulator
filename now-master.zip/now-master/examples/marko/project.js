module.exports = require('marko-starter').projectConfig({
  name: 'marko-starter-demo', // Optional, but added here for demo purposes
});
