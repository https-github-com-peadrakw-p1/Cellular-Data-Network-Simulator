export default {
  dest: '/public',
  public: '/pub',
};
