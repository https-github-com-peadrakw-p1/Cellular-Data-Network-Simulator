---
# Fallback to `default` layout if `index` is not found
layout: index
# Inject post list as `page.posts` (by saber-plugin-query-posts)
injectAllPosts: true
---
