---
title: About
layout: page
---

This is the Saber port of the base Jekyll theme. Check out the [GitHub project](https://github.com/egoist/saber-theme-minima) for detailed usages.

You can find out more info about customizing your theme, as well as basic Saber usage documentation at https://saber.land
